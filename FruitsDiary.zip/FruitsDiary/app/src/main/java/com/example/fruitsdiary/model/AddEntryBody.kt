package com.example.fruitsdiary.model

class AddEntryBody(var date: String? = "")
