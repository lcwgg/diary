package com.example.fruitsdiary.model

class Response(var code: String = "", var message: String = "")
